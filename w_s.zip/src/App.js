import React from 'react';
import { Header } from './components';
import { Home, Cart, Glavnaya, Onas } from './pages';
import { Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="wrapper">
      <Header />
      <div className="content">
        <Routes>
          <Route path="/" element={<Glavnaya />} />
          <Route path="/home" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/onas" element={<Onas />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;

// Импорт файлов 

// function App() {

//   const root = ReactDOM.createRoot(document.getElementById("root"));

//   root.render(
//     <BrowserRouter>
//       <Routes>
//         <Route path="/" element={Home} />
//         <Route path="/cart" element={Cart} />
//       </Routes>ё 
//     </BrowserRouter>
//   );
// }