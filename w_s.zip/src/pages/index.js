// экспорт файлов для легкого доступа и без повторных импортов.

export { default as Home } from './Home';
export { default as Cart } from './Cart';
export { default as Glavnaya } from './Glavnaya';
export { default as Onas } from './Onas';
