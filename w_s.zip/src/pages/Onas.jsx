import React from 'react'

function Onas() {
  return (
    <div className="onas"> 

        <span className='text1'>О нас</span>
        <span className='text2'>Сайт создан для выбора одежды не выходя из дома <br/> и для того что бы не стоять в очереди. <br/>А просто придти и забрать товар или же заказать на дом.</span>
        <span className='text3'>Почта для связи: w_store@gmail.com</span>
        {/* <img src='https://cdn.icon-icons.com/icons2/1452/PNG/512/code-girl-folder_99393.png'></img> */}
    </div>
  )
}
export default Onas