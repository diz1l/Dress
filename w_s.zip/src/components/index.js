// экспорт файлов для легкого доступа и без повторных импортов.

export { default as Button } from './Button';
export { default as Header } from './Header';
export { default as Categories } from './Categories';
export { default as SortPopup } from './SortPopup';
export { default as CartItem } from './CartItem';
export { default as DressBlock } from './DressBlock';
export { default as LoadingBlock } from './DressBlock/LoadingBlock';


// import Button from "./Button";
// import Header from "./Header";
// import Categories from "./Categories";
// export { Button, Header, Categories };


